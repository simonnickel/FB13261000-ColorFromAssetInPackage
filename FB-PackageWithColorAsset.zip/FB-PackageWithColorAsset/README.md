# FBPackageWithColorAssetTests

A Swift Package with a Color from an Asset Catalog.
